package com.example.tugasrecycleview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MyRecyclerViewAdapter.ItemClickListener  {
    MyRecyclerViewAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<String> masjid = new ArrayList<>();
        masjid.add("Masjid Islamic Center");
        masjid.add("Masjid Ar-Raisiyah Sekarbela");
        masjid.add("Masjid Raya At-Takwa Mataram");
        masjid.add("Masjid Baitussalam Sekarbela");
        masjid.add("Masjid Almustofa Pesinggahan");
        masjid.add("Masjid Baiturrahman Sekarbela");
        masjid.add("Masjid Baiturrahim Punik");
        masjid.add("Masjid Nurul A'la Karang Pule");

        // set up the RecyclerView
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.rvMasjid);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyRecyclerViewAdapter(this, masjid);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onItemClick(View view, int position) {
        Toast.makeText(this, "Anda Memilih " + adapter.getItem(position).toString(), Toast.LENGTH_SHORT).show();
    }
    }

